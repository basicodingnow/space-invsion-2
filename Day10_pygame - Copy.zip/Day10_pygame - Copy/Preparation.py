# STEPS:
# 1) go to pypi.org
# 2) install pygame : https://pypi.org/project/pygame/
#   - get the pip install code: pip install pygame
#   - open terminal in Pycharm and install the package
# 3) Now we can start coding in pycharm IDE

# Tip: glance over the pygame docs: https://www.pygame.org/docs/